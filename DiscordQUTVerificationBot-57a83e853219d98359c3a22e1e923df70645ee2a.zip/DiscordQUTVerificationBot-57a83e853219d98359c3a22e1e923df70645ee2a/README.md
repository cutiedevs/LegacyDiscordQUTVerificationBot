# QUTBot: A Discord bot for QUT servers

Built on discord.py

## Features

* Verify QUT students via their student number

* Create a unique verification code for each verification request

* Post the changelog in announcements channel

* General Discord moderation

## Planned features

* Assigning roles according to units

## Contributors

 * [Tarang74](https://github.com/Tarang74)

 * [ben-S-lgtm](https://github.com/ben-S-lgtm)
