from main import *
from random import randint

