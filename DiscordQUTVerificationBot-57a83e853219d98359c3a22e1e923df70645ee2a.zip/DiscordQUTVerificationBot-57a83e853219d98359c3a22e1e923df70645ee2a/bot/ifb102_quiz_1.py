topic_1 = {
    1: {
        "question": "test1",
        "answer": "test1"
    },
    2: {
        "question": "test2",
        "answer": "test2"
    },
    3: {
        "question": "test3",
        "answer": "test3"
    },
    4: {
        "question": "test4",
        "answer": "test4"
    },
    5: {
        "question": "test5",
        "answer": "test5"
    },
    6: {
        "question": "test6",
        "answer": "test6"
    },
    7: {
        "question": "test7",
        "answer": "test7"
    },
    8: {
        "question": "test8",
        "answer": "test8"
    },
    9: {
        "question": "test9",
        "answer": "test9"
    },
    10: {
        "question": "test10",
        "answer": "test10"
    }
}
topic_2 = {
    11: {
        "question": "test11",
        "answer": "test11"
    },
    12: {
        "question": "test12",
        "answer": "test12"
    },
    13: {
        "question": "test13",
        "answer": "test13"
    },
    14: {
        "question": "test14",
        "answer": "test14"
    },
    15: {
        "question": "test15",
        "answer": "test15"
    },
    16: {
        "question": "test16",
        "answer": "test16"
    },
    17: {
        "question": "test17",
        "answer": "test17"
    },
    18: {
        "question": "test18",
        "answer": "test18"
    },
    19: {
        "question": "test91",
        "answer": "test19"
    },
    20: {
        "question": "test20",
        "answer": "test20"
    }
}
topic_3 = {
    21: {
        "question": "test21",
        "answer": "test21"
    },
    22: {
        "question": "test22",
        "answer": "test22"
    },
    23: {
        "question": "test23",
        "answer": "test23"
    },
    24: {
        "question": "test24",
        "answer": "test24"
    },
    25: {
        "question": "test25",
        "answer": "test25"
    },
    26: {
        "question": "test26",
        "answer": "test26"
    },
    27: {
        "question": "test27",
        "answer": "test27"
    },
    28: {
        "question": "test28",
        "answer": "test28"
    },
    29: {
        "question": "test29",
        "answer": "test29"
    },
    30: {
        "question": "test30",
        "answer": "test30"
    }
}
topic_4 = {
    31: {
        "question": "test31",
        "answer": "test31"
    },
    32: {
        "question": "test32",
        "answer": "test32"
    },
    33: {
        "question": "test33",
        "answer": "test33"
    },
    34: {
        "question": "test34",
        "answer": "test34"
    },
    35: {
        "question": "test35",
        "answer": "test35"
    },
    36: {
        "question": "test36",
        "answer": "test36"
    },
    37: {
        "question": "test37",
        "answer": "test37"
    },
    38: {
        "question": "test38",
        "answer": "test38"
    },
    39: {
        "question": "test39",
        "answer": "test39"
    },
    40: {
        "question": "test40",
        "answer": "test40"
    }
}